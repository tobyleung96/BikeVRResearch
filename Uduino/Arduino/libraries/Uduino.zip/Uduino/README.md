Uduino.h
===============

Uduino is a Unity plugin simplifying communication between Arduino and Unity. It has all the mapping features most developers need for their interactive installations.

Uduino aims to be a easy and simple, yet powerful solution for your Arduino/Unity experiments or projects. It works efficiently across all major desktop operating systems, and features examples and use a simple and readable API.


## More informations : https://marcteyssier.com/uduino/